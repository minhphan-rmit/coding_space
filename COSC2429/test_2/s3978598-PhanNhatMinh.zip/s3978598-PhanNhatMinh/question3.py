# RMIT University Vietnam
# Course: COSC2429 Introduction to Programming
# Semester: 2022C
# Assignment: Individual - Timed Programming Lab Test 2 (25%)
# Author: Phan Nhat Minh (s3978598)
# Created date: 17/12/2022
# Last modified date: 17/12/2022
# IDE: Pycharm 2022.2.3 (Professional Edition)
# Python version: 3.11
# Question: 3


def max_num(nums):
    """
    This function find the maximum number in a list of numbers and the index of that number in the list
    :param nums: given list of numbers by the user
    :return: the maximum value, and it's index
    """
    num_list = nums.split(' ')
    max_val = 0
    idx = []
    for num in num_list:
        if float(num) > max_val:
            max_val = float(num)
        else:
            max_val = max_val

    while num_list.count(str(max_val)) != 0:
        idx.append(num_list.index(str(max_val)))

    return max_val, idx


def print_result(max_val, idx):
    """
    This is a non-fruitful function to print the result in the correct format
    :param max_val: maximum value
    :param idx: the indexes of that value
    :return: the correct format result
    """
    print(f"The maximum number is {max_val} at position(s) {', '.join(idx)}")


# main program
numbers = input('Enter a sequence of numbers: ')
max_number, pos = max_num(numbers)
print_result(max_number, pos)
