# RMIT University Vietnam
# Course: COSC2429 Introduction to Programming
# Semester: 2022C
# Assignment: Assignment 4 - Test 3
# Author: Phan Nhat Minh (s3978598)
# Created date: 14/01/2023
# Last modified date: 14/01/2023
# IDE: Pycharm 2022.2.3 (Professional Edition)
# Python version: 3.11
# Question: 2


# functions
def remove_del_items(info: dict):
    """
    This function removes the items that labelled deleted in a dictionary
    :param info: a given dictionary
    :return: a new dictionary without deleted items
    """
    # create an empty dict
    new_info = {}
    # loop through the original dictionary
    for keys, val in info.items():
        # if the value is not DELETED then add it to the new dictionary
        if val != 'DELETED':
            new_info[str(keys)] = val

    # return the new dictionary
    return new_info


def write_output(info):
    """
    This function writes the output into a new file
    :param info: a given dictionary
    :return: output file with the extension .txt
    """
    # create and write on a new file
    out_file = open('output.txt', 'x')      # create a new file called output.txt
    out_file = open('output.txt', 'w')      # write on a file called output.txt

    # loop through pair of keys and values in the dictionary
    for keys, val in info.items():
        # write the result in the correct format
        out_file.write(f"{keys}: {val}")
        out_file.write('\n')

    # close the file
    out_file.close()


# main program
# given dictionary
student = {
    'ID': 's3962053',
    'Name': 'Huynh Tin',
    'University': 'RMIT',
    'Major': 'Information Technology',
    'Year': 2022,
    'Python': 'DI',
    'OOP': 'HD',
    'Network': 'DELETED',
    'C++': 'DI',
    'Web': 'DELETED',
    'Java': 'CR'
}
# remove the deleted labelled items
del_info = remove_del_items(student)
# call the function to write the output file
write_output(del_info)
