# this is the dictionary for question 2
# main program
student = {
    'ID': 's3962053',
    'Name': 'Huynh Tin',
    'University': 'RMIT',
    'Major': 'Information Technology',
    'Year': 2022,
    'Python': 'DI',
    'OOP': 'HD',
    'Network': 'DELETED',
    'C++': 'DI',
    'Web': 'DELETED',
    'Java': 'CR'
}

