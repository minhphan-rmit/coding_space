#ifndef __MAIN_H__
#define __MAIN_H__

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

using namespace std;

#endif